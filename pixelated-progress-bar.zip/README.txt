A Pen created at CodePen.io. You can find this one at http://codepen.io/achudars/pen/bgcsp.

 Inspired by this: http://dribbble.com/shots/1069974-Modern-Loading-Screen